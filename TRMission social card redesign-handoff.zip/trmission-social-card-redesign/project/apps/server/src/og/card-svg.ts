// =============================================================================
// TRMission — Open Graph social cards
// Direction: "Ticket stub" (railway timetable on warm paper)
//
// Output: a raw SVG string, rasterized server-side by @resvg/resvg-js.
// resvg is a static Rust renderer, NOT a browser. Constraints honoured here:
//   - No CSS layout (flex/grid), no @font-face / web fonts, no filters / blend
//     modes. Only the SVG shape+text+transform subset resvg supports.
//   - Text uses installed system fonts only (loadSystemFonts). Font stacks list
//     CJK-capable families first, Latin/mono fallbacks after.
//   - "Semibold" is unreliable across environments, so heavy text is faux-bolded
//     with a paint-order stroke in the same fill colour (thickens glyphs without
//     needing a 600/700 face to exist).
//   - Fixed 1200×630. All dynamic strings are escaped and length-managed.
//   - Zero external assets. Everything is inline geometry.
// =============================================================================

// ------------------------------------------------------------------ dimensions
const W = 1200;
const H = 630;
const STUB_W = 330; // blue tear-off stub carrying the brand

// -------------------------------------------------------------------- palette
const C = {
  blue: "#0f5fa6",
  blueTint: "#bcd4ea", // legible on blue stub
  ember: "#ee6b1f",
  paper: "#f6f1e7",
  surface: "#fffdf8",
  surface2: "#efe8da",
  ink: "#1f2328",
  ink2: "#5b6168",
  line: "#d9d0be",
  white: "#fffdf8",
} as const;

// 5 seat colours, index-addressable. Callers may pass an explicit colour per
// player; this is the canonical order for anything that maps seat -> colour.
export const SEAT_COLORS = [
  "#0E8C8C",
  "#C0398B",
  "#E8A33D",
  "#5A6B7B",
  "#7CB342",
] as const;

// ------------------------------------------------------------------ font stacks
// Listed CJK-first so a mixed CN+Latin string renders from one family where
// possible; resvg falls through the list per glyph.
const F_SANS =
  "'PingFang TC','Microsoft JhengHei','Noto Sans TC','Noto Sans CJK TC','Helvetica','Arial','DejaVu Sans',sans-serif";
const F_MONO = "'DejaVu Sans Mono','Menlo','Consolas',monospace";
const F_LATIN = "'Helvetica','Arial','DejaVu Sans',sans-serif";

// =============================================================================
// helpers
// =============================================================================

/** Escape a dynamic string for inclusion in SVG text / attribute content. */
function esc(s: unknown): string {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

/**
 * Approximate rendered width of a string at a given font size.
 * CJK glyphs are ~full-em; Latin/space ~0.55em on the sans stack. This is only
 * used to decide truncation + code auto-sizing, so an estimate is fine.
 */
function approxWidth(s: string, fontSize: number, cjkEm = 1.0, latinEm = 0.56) {
  let units = 0;
  for (const ch of s) {
    // CJK Unified + common CJK ranges -> full width
    units += /[\u2E80-\u9FFF\uF900-\uFAFF\uFF00-\uFFEF]/.test(ch)
      ? cjkEm
      : latinEm;
  }
  return units * fontSize;
}

/**
 * Truncate to fit maxWidth at fontSize, appending an ellipsis if cut.
 * Works per code-point so it never splits a surrogate pair (emoji / rare CJK).
 */
function fit(raw: string, maxWidth: number, fontSize: number): string {
  const s = String(raw ?? "");
  if (approxWidth(s, fontSize) <= maxWidth) return s;
  const chars = Array.from(s);
  const ell = "…";
  const ellW = approxWidth(ell, fontSize);
  let acc = "";
  for (const ch of chars) {
    if (approxWidth(acc + ch, fontSize) + ellW > maxWidth) break;
    acc += ch;
  }
  return (acc.replace(/\s+$/, "") || chars[0] || "") + ell;
}

/** A <text> element. `bold` adds the faux-bold stroke in the fill colour. */
function text(
  x: number,
  y: number,
  content: string,
  opts: {
    size: number;
    fill: string;
    font?: string;
    anchor?: "start" | "middle" | "end";
    spacing?: number;
    bold?: number; // stroke-width for faux bold; omit for regular
    escape?: boolean; // set false when content is already-safe markup-free literal
  }
): string {
  const {
    size,
    fill,
    font = F_SANS,
    anchor = "start",
    spacing,
    bold,
    escape = true,
  } = opts;
  const body = escape ? esc(content) : content;
  const boldAttrs = bold
    ? ` paint-order="stroke" stroke="${fill}" stroke-width="${bold}" stroke-linejoin="round"`
    : "";
  const sp = spacing != null ? ` letter-spacing="${spacing}"` : "";
  return `<text x="${x}" y="${y}" font-family="${font}" font-size="${size}" fill="${fill}" text-anchor="${anchor}"${sp}${boldAttrs}>${body}</text>`;
}

/** The shared blue tear-off stub + paper base. `label` is the small CN·EN tab. */
function shell(label: string, opts: { footer?: string } = {}): string {
  const brand = text(0, 0, "台鐵任務", {
    size: 58,
    fill: C.white,
    font: F_SANS,
    bold: 1,
    escape: false,
  });
  return `
    <rect width="${W}" height="${H}" fill="${C.paper}"/>
    <rect width="${STUB_W}" height="${H}" fill="${C.blue}"/>
    <rect x="${STUB_W}" y="0" width="6" height="${H}" fill="${C.ember}"/>
    <line x1="${STUB_W + 22}" y1="24" x2="${STUB_W + 22}" y2="${H - 24}" stroke="${C.paper}" stroke-width="4" stroke-dasharray="3 12"/>
    <circle cx="${STUB_W + 22}" cy="0" r="20" fill="${C.paper}"/>
    <circle cx="${STUB_W + 22}" cy="${H}" r="20" fill="${C.paper}"/>
    ${text(40, 70, label, { size: 22, fill: C.blueTint, font: F_MONO, spacing: 4, escape: false })}
    <g transform="translate(150,470) rotate(-90)">${brand}</g>
    <text transform="translate(214,470) rotate(-90)" font-family="${F_LATIN}" font-size="26" letter-spacing="7" fill="${C.blueTint}">TRMISSION</text>
    <circle cx="150" cy="500" r="4" fill="${C.ember}"/>
    ${opts.footer ? text(40, 580, opts.footer, { size: 20, fill: C.blueTint, font: F_MONO }) : ""}
  `;
}

function svg(children: string): string {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}"><rect width="${W}" height="${H}" fill="${C.paper}"/>${children}</svg>`;
}

// The main content column starts to the right of the stub.
const MX = 392; // main-column left edge
const MR = 1120; // main-column right edge
const MAIN_W = MR - MX;

// =============================================================================
// 1) SITE CARD  — brand lockup + tagline; also the private/unknown fallback.
// =============================================================================
export function siteCardSvg(input?: {
  tagline?: string;
  domain?: string;
}): string {
  const tagline = input?.tagline ?? "連接全島城市，成為最強車長。";
  const domain = input?.domain ?? "trmission.app";

  // seat-coloured route nodes along a single line = the recurring motif
  const nodeXs = [MX, 574, 756, 938];
  const nodes = nodeXs
    .map(
      (x, i) =>
        `<circle cx="${x}" cy="470" r="12" fill="${C.paper}" stroke="${SEAT_COLORS[i]}" stroke-width="5"/>`
    )
    .join("");

  return svg(`
    ${shell("車票 · ADMIT ONE")}
    ${text(MX, 150, "路線建設桌遊 · 台灣特別版", { size: 24, fill: C.ink2, font: F_MONO, spacing: 3, escape: false })}
    ${text(MX - 4, 290, "搶線・連城", { size: 104, fill: C.ink, bold: 1.4, escape: false })}
    ${text(MX, 360, fit(tagline, MAIN_W, 40), { size: 40, fill: C.ink2 })}
    <line x1="${MX}" y1="470" x2="${MR}" y2="470" stroke="${C.blue}" stroke-width="3"/>
    ${nodes}
    <circle cx="${MR}" cy="470" r="14" fill="${C.ember}"/>
    ${text(MX, 586, `${esc(domain)} · 立即開局`, { size: 24, fill: C.ink2, font: F_MONO, escape: false })}
  `);
}

// =============================================================================
// 2) ROOM INVITE CARD  — room code is the hero; host / seats / map / status.
// =============================================================================
export function roomCardSvg(input: {
  code: string;
  host: string;
  seats: number;
  maxSeats: number;
  mapName: string;
  status?: "open" | "full" | "playing" | "closed";
}): string {
  const code = String(input.code ?? "").toUpperCase();

  // Auto-size the hero code so 4–8+ chars all fill the field without overflow.
  // Field runs MX..MR; find the largest size whose est. width fits, capped.
  const spacing = code.length <= 6 ? 8 : 4;
  let codeSize = 190;
  while (
    codeSize > 60 &&
    approxWidth(code, codeSize, 1, 0.62) + spacing * (code.length - 1) >
      MAIN_W
  ) {
    codeSize -= 2;
  }

  const st = input.status ?? "open";
  const statusMap: Record<string, { cn: string; en: string; fill: string }> = {
    open: { cn: "開放中", en: "OPEN", fill: C.ember },
    full: { cn: "已滿員", en: "FULL", fill: C.ink2 },
    playing: { cn: "進行中", en: "PLAYING", fill: C.blue },
    closed: { cn: "已關閉", en: "CLOSED", fill: C.ink2 },
  };
  const badge = statusMap[st] ?? statusMap.open;
  const badgeLabel = `${badge.cn} · ${badge.en}`;
  const badgeW = Math.max(200, approxWidth(badgeLabel, 25) + 96);

  // clamp seats display defensively
  const seats = Math.max(0, Math.floor(input.seats || 0));
  const maxSeats = Math.max(seats, Math.floor(input.maxSeats || 0));

  return svg(`
    ${shell("房間 · ROOM", { footer: `${seats}/${maxSeats} 席` })}
    ${text(MX, 150, "房間代碼 · ROOM CODE", { size: 24, fill: C.ink2, font: F_MONO, spacing: 4, escape: false })}
    ${text(MX - 4, 330, code, { size: codeSize, fill: C.blue, font: F_MONO, spacing, bold: 2 })}

    <rect x="${MX}" y="378" width="${badgeW}" height="48" rx="24" fill="${badge.fill}"/>
    <circle cx="${MX + 34}" cy="402" r="7" fill="${C.surface}"/>
    ${text(MX + 56, 411, badgeLabel, { size: 25, fill: C.surface, escape: false })}

    <line x1="${MX}" y1="452" x2="${MR}" y2="452" stroke="${C.line}" stroke-width="2"/>

    ${text(MX, 510, "主持人", { size: 19, fill: C.ink2, font: F_MONO, spacing: 2, escape: false })}
    ${text(MX, 548, fit(input.host, 200, 32), { size: 32, fill: C.ink })}
    <circle cx="620" cy="500" r="4" fill="${C.ember}"/>
    ${text(648, 510, "座位", { size: 19, fill: C.ink2, font: F_MONO, spacing: 2, escape: false })}
    ${text(648, 548, `${seats} / ${maxSeats}`, { size: 32, fill: C.ink, font: F_MONO })}
    <circle cx="820" cy="500" r="4" fill="${C.ember}"/>
    ${text(848, 510, "地圖", { size: 19, fill: C.ink2, font: F_MONO, spacing: 2, escape: false })}
    ${text(848, 548, fit(input.mapName, MR - 848, 32), { size: 32, fill: C.ink })}
  `);
}

// =============================================================================
// 3) REPLAY SCOREBOARD CARD — map + date + up to 5 ranked players, winner marked.
// =============================================================================
export function replayCardSvg(input: {
  mapName: string;
  date: string; // pre-formatted, e.g. "2026.07.01"
  players: Array<{ name: string; score: number; seatColor?: string }>;
}): string {
  // Rank by score desc; cap at 5. Winner = rank 1 (ties: first listed).
  const players = [...(input.players ?? [])]
    .sort((a, b) => (b.score ?? 0) - (a.score ?? 0))
    .slice(0, 5);

  const ROW_Y0 = 171; // first-row baseline-ish centre
  const ROW_H = 82;
  const nameMaxW = 1120 - 510; // right edge for names before score column

  const rows = players
    .map((p, i) => {
      const cy = ROW_Y0 + i * ROW_H;
      const isWin = i === 0;
      const seat = p.seatColor || SEAT_COLORS[i % SEAT_COLORS.length];
      const rankBadge = isWin
        ? `<circle cx="418" cy="${cy}" r="22" fill="${C.ember}"/>` +
          text(418, cy + 10, String(i + 1), {
            size: 26,
            fill: C.surface,
            font: F_MONO,
            anchor: "middle",
            bold: 0.8,
            escape: false,
          })
        : text(418, cy + 10, String(i + 1), {
            size: 26,
            fill: C.ink2,
            font: F_MONO,
            anchor: "middle",
            escape: false,
          });
      const swatch = `<rect x="458" y="${cy - 18}" width="34" height="34" rx="8" fill="${seat}"/>`;
      // winner keeps a little room for the 冠軍 pill after the name
      const nameW = isWin ? nameMaxW - 120 : nameMaxW;
      const name = text(510, cy + 13, fit(p.name, nameW, 38), {
        size: 38,
        fill: C.ink,
      });
      const crown = isWin
        ? `<rect x="${510 + Math.min(approxWidth(fit(p.name, nameW, 38), 38) + 18, nameW - 90)}" y="${cy - 19}" width="86" height="36" rx="18" fill="${C.ember}"/>` +
          text(
            510 +
              Math.min(approxWidth(fit(p.name, nameW, 38), 38) + 18, nameW - 90) +
              43,
            cy + 6,
            "冠軍",
            { size: 22, fill: C.surface, anchor: "middle", escape: false }
          )
        : "";
      const score = text(1120, cy + 13, String(p.score ?? 0), {
        size: isWin ? 46 : 44,
        fill: isWin ? C.ember : C.blue,
        font: F_MONO,
        anchor: "end",
        bold: isWin ? 0.8 : undefined,
        escape: false,
      });
      const divider =
        i < players.length - 1 && i !== 0
          ? `<line x1="${MX}" y1="${cy + ROW_H / 2}" x2="${MR}" y2="${cy + ROW_H / 2}" stroke="${C.line}" stroke-width="1.5"/>`
          : "";
      const highlight = isWin
        ? `<rect x="376" y="${cy - 31}" width="760" height="62" rx="10" fill="${C.ember}" opacity="0.12"/>`
        : "";
      return highlight + rankBadge + swatch + name + crown + score + divider;
    })
    .join("");

  return svg(`
    ${shell("回顧 · REPLAY", { footer: esc(input.date) })}
    ${text(MX, 98, fit(input.mapName, MAIN_W, 46), { size: 46, fill: C.ink, bold: 1 })}
    <line x1="${MX}" y1="122" x2="${MR}" y2="122" stroke="${C.blue}" stroke-width="2"/>
    ${rows}
  `);
}
